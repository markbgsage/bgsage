"""Independently verify the completed local Paskogammon cohort."""

from collections import Counter
import json
from math import isclose, sqrt
from pathlib import Path
from random import Random
import sqlite3
from statistics import NormalDist, fmean, stdev
import winreg


FOLDER = Path(__file__).resolve().parent
SETTINGS = r"Software\GameSite 2000\eXtreme Gammon 2\Analzye"


def main():
    report = json.loads((FOLDER / "result.json").read_text(encoding="utf-8"))
    records = report["games"]
    assert len(records) == report["game_count"] == 5000
    assert report["seed"] == 2026112344
    assert report["variant"] == "paskogammon"
    assert report["player_a"] == {"bot": "sage", "eval_level": "truncated1"}
    assert report["player_b"] == {"bot": "xg", "eval_level": "truncated1"}
    assert report["xg"]["opening_book"] and report["xg"]["profile"]["stages"] == {"move": [1000], "cube": [1000]}
    assert report["reference"] == "sage_2ply_nd" and report["beta"] == 1
    assert report["rules"] == {"jacoby": True, "beaver": False, "max_cube_value": 64, "max_turns": 1000}

    black_frame = [0, -2, -2, 0, 0, -1, 5, -1, 3, 0, 0, 0, -2,
                   5, 0, 0, 0, -2, -1, -3, -1, 0, 0, 0, 2, 0]
    assert report["start_board"] == [black_frame[-1], *(-p for p in black_frame[-2:0:-1]), black_frame[0]]
    rng = Random(report["seed"])
    seeds = {}
    while len(seeds) < len(records):
        seed = rng.getrandbits(31)
        seeds.setdefault(seed, len(seeds) % 2 + 1)
    assert [record["seed"] for record in records] == list(seeds)

    first_rolls = Counter()
    first_cubes = Counter()
    for record in records:
        seed = record["seed"]
        assert record["start_player"] == seeds[seed]
        rng = Random(seed)
        dice = record["first_roll"]
        if dice is None:
            assert record["first_cube_action"] == "double/pass"
        else:
            assert dice == [rng.randint(1, 6), rng.randint(1, 6)]
            first_rolls[tuple(dice)] += 1
        first_cubes[record["first_cube_action"]] += 1
        assert record["adjusted_points"] == record["raw_points"] - record["luck_points"]
    assert len(first_rolls) == 36
    db_uri = (FOLDER / "checkpoint.sqlite").as_uri() + "?mode=ro"
    with sqlite3.connect(db_uri, uri=True) as db:
        saved = {seed: json.loads(record) for seed, record in db.execute("select * from games")}
    assert saved == {record["seed"]: record for record in records}

    groups = [[record for record in records if record["start_player"] == player] for player in (1, 2)]
    assert [len(group) for group in groups] == [2500, 2500]
    z = NormalDist().inv_cdf(0.975)
    for metric in ("raw", "luck", "adjusted"):
        samples = [[record[metric + "_points"] for record in group] for group in groups]
        center = (fmean(samples[0]) + fmean(samples[1])) / 2
        se = sqrt(sum(stdev(sample) ** 2 / len(sample) for sample in samples)) / 2
        reported = report["balanced_estimates"][metric]
        assert isclose(reported["mean_ppg"], center)
        assert isclose(reported["se_ppg"], se)
        assert all(isclose(x, center + sign * z * se)
                   for x, sign in zip(reported["ci95_ppg"], (-1, 1)))

    before = json.loads((FOLDER / "xg-settings-before.json").read_text(encoding="utf-8-sig"))
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, SETTINGS) as registry:
        assert before == {name: winreg.QueryValueEx(registry, name)[0] for name in before}
    log = (FOLDER / "run.stdout.log").read_text(encoding="utf-8")
    print(json.dumps({"games": len(records), "opener_counts": Counter(g["start_player"] for g in records),
                      "wins": Counter(g["winner"] for g in records), "first_cube_actions": first_cubes,
                      "first_roll_doubles": sum(first_rolls[d, d] for d in range(1, 7)),
                      "wall_seconds": report["wall_seconds"], "estimates": report["balanced_estimates"],
                      "xg_batches": report["xg"]["batch_count"], "xg_decisions": report["xg"]["decision_count"],
                      "rejected_batch_attempts": [line for line in log.splitlines() if "attempt " in line],
                      "xg_settings_restored": True}, indent=2))


if __name__ == "__main__":
    main()
