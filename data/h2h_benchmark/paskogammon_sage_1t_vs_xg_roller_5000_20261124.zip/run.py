# SPDX-License-Identifier: MPL-2.0
# Copyright (C) 2026 Mark Higgins
"""Replay the fixed 5,000-game Paskogammon Sage 1T vs XG Roller benchmark cohort."""

from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack, contextmanager
from dataclasses import replace
from datetime import datetime, timezone
from hashlib import sha256
import json
from math import hypot
import os
from pathlib import Path
from random import Random
import sqlite3
from threading import Thread, local
from time import monotonic, thread_time
import winreg

from bgsage import BgBotAnalyzer
from bgsage import h2h
from bgsage.board import flip_board
from bgsage.simulation import GameConfig
from bgsage.xg_h2h import _DEFAULT_EXE, _PROFILE_KEY, _QueuedPolicy, _session, _xg_is_running


PROJECT_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_DIR = PROJECT_ROOT / "logs" / "pasko-sage-1t-vs-xg-roller-5000-20261123"
SEED = 2026112344
COUNT = 5000
STREAMS = int(os.environ.get("BGSAGE_XG_GAME_STREAMS", "256"))
SAGE_WORKERS = int(os.environ.get("BGSAGE_XG_SAGE_WORKERS", "20"))
PROFILE = "Sage H2H Roller"
PROFILE_SLOT = "5"
ORIGINAL_PROFILE = "Sage3P:2:-1:-1:-1:-1:-1::2:-1:-1:-1:-1"
ROLLER_PROFILE = f"{PROFILE}:1000:-1:-1:-1:-1:-1::1000:-1:-1:-1:-1"
# Standard-layout side's frame from the Pasko training and benchmark setup.
# For head-to-head, the scattered side moves first with alternating engines.
PASKO_BLACK = [0, -2, -2, 0, 0, -1, 5, -1, 3, 0, 0, 0, -2,
               5, 0, 0, 0, -2, -1, -3, -1, 0, 0, 0, 2, 0]
CONFIG = GameConfig(start_board=tuple(flip_board(PASKO_BLACK)), max_cube_value=64)
STARTS = {1: CONFIG, 2: replace(CONFIG, player_on_roll=2)}
START = monotonic()


def log(message):
    print(f"{datetime.now(timezone.utc).isoformat(timespec='seconds')} {message}", flush=True)


def write_json(path, value):
    partial = path.with_suffix(".part")
    partial.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    partial.replace(path)


@contextmanager
def roller_session():
    if _xg_is_running(_DEFAULT_EXE):
        raise RuntimeError("Close XG before borrowing the inactive benchmark profile slot")
    access = winreg.KEY_QUERY_VALUE | winreg.KEY_SET_VALUE
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _PROFILE_KEY, 0, access) as key:
        saved = winreg.QueryValueEx(key, PROFILE_SLOT)
        if saved != (ORIGINAL_PROFILE, winreg.REG_SZ):
            raise RuntimeError("XG slot 5 no longer contains the expected Sage3P profile")
        winreg.SetValueEx(key, PROFILE_SLOT, 0, saved[1], ROLLER_PROFILE)
        try:
            with _session("truncated1", PROFILE, None, None, CONFIG.max_cube_value) as session:
                yield session
        finally:
            if winreg.QueryValueEx(key, PROFILE_SLOT) != (ROLLER_PROFILE, saved[1]):
                raise RuntimeError("XG slot 5 changed during play; see xg-settings-before.json")
            winreg.SetValueEx(key, PROFILE_SLOT, 0, saved[1], saved[0])


class Oracle:
    def __init__(self, db):
        self.db = db
        self.stack = ExitStack()
        self.current = None
        self.info = None
        self.next_recycle = 125

    def start(self):
        self.current, info = self.stack.enter_context(roller_session())
        if self.info is not None and self.info != info:
            raise RuntimeError("XG executable, template or profile changed between sessions")
        self.info = info
        with sqlite3.connect(self.db) as connection:
            previous = connection.execute("select value from metadata where key = 'xg'").fetchone()
            if previous and json.loads(previous[0]) != json.loads(json.dumps(info)):
                raise RuntimeError("XG identity differs from the saved cohort")
            connection.execute("insert or ignore into metadata values ('xg', ?)", (json.dumps(info),))
        log(f"XG PID {self.current.process.pid} calibrated at checker and cube Roller with book enabled")

    def stop(self):
        try:
            self.stack.close()
        finally:
            self.current = None

    def analyze(self, requests):
        for attempt in range(3):
            try:
                if self.current is not None and self.current.rounds >= self.next_recycle:
                    self.stop()
                if self.current is None:
                    self.start()
                begin = monotonic()
                results = self.current.analyze(requests)
                seconds = monotonic() - begin
                with sqlite3.connect(self.db) as connection:
                    connection.execute("insert into batches (items, seconds) values (?, ?)",
                                       (len(requests), seconds))
                if self.current.rounds % 20 == 0:
                    log(f"XG PID {self.current.process.pid} finished batch {self.current.rounds}; "
                        f"{len(requests)} decisions in {seconds:.2f}s")
                return results
            except (OSError, ValueError, RuntimeError) as error:
                log(f"XG attempt {attempt + 1} failed: {type(error).__name__}: {error}")
                self.stop()
                if attempt == 2:
                    raise
        raise AssertionError("unreachable")


class SagePool:
    def __init__(self, executor):
        self.executor = executor
        self.native = local()
        self.game = local()

    def _execute(self, operation, args, kwargs, rollout_seed):
        if not hasattr(self.native, "player"):
            self.native.player = BgBotAnalyzer(eval_level="truncated1", parallel_threads=1)
            self.native.scorer = h2h._LuckScorer(BgBotAnalyzer(eval_level="2ply", parallel_threads=1), CONFIG)
        target = self.native.scorer if operation == "score" else self.native.player
        before = thread_time()
        if rollout_seed is not None:
            target.set_seed(rollout_seed)
        value = getattr(target, operation)(*args, **kwargs)
        return value, thread_time() - before

    def call(self, operation, *args, **kwargs):
        rollout_seed = None if operation == "score" else self.game.rollout_rng.getrandbits(31)
        value, seconds = self.executor.submit(self._execute, operation, args, kwargs, rollout_seed).result()
        self.game.native_seconds = getattr(self.game, "native_seconds", 0.0) + seconds
        return value

    def checker_play(self, *args, **kwargs):
        return self.call("checker_play", *args, **kwargs)

    def cube_action(self, *args, **kwargs):
        return self.call("cube_action", *args, **kwargs)

    def score(self, game):
        if game["start_board"] != list(CONFIG.start_board) or game["start_player"] != self.game.opener:
            raise RuntimeError("Game did not start in the scheduled Paskogammon position")
        self.game.first_roll = game["turns"][0]["dice"]
        self.game.first_cube = game["turns"][0]["cube_action"]
        return self.call("score", game)

    def cpu_clock(self):
        return thread_time() + getattr(self.game, "native_seconds", 0.0)


class Runner(h2h._GameRunner):
    def __init__(self, sage, xg, openers):
        self.players = (sage, xg)
        self.scorer = sage
        self.openers = openers
        self.beta = 1.0
        self.cpu_clock = sage.cpu_clock

    @property
    def config(self):
        return STARTS[self.scorer.game.opener]

    def play(self, seed):
        self.scorer.game.opener = self.openers[seed]
        self.scorer.game.rollout_rng = Random(seed ^ 0x5167A19B)
        record = super().play(seed)
        return dict(record, first_roll=self.scorer.game.first_roll,
                    first_cube_action=self.scorer.game.first_cube)


def balanced_estimates(records):
    groups = [[record for record in records if record["start_player"] == opener]
              for opener in (1, 2)]
    if len(groups[0]) != len(groups[1]) or len(groups[0]) != COUNT // 2:
        raise RuntimeError("The cohort did not split evenly by opener")
    summaries = [h2h._summarize(group, external_bot=True) for group in groups]
    estimates = {}
    for field in ("raw", "luck", "adjusted"):
        a, b = (summary[field] for summary in summaries)
        mean = (a["mean_ppg"] + b["mean_ppg"]) / 2
        se = hypot(a["se_ppg"], b["se_ppg"]) / 2
        radius = h2h._NORMAL_95 * se
        estimates[field] = {"mean_ppg": mean, "se_ppg": se,
                            "ci95_ppg": [mean - radius, mean + radius]}
    raw, adjusted = (estimates[field]["se_ppg"] for field in ("raw", "adjusted"))
    estimates["se_reduction_percent"] = 100 * (1 - adjusted / raw) if raw else None
    estimates["variance_ratio"] = (raw / adjusted) ** 2 if adjusted else None
    return estimates, {"sage_first": summaries[0], "xg_first": summaries[1]}


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    result_path = OUTPUT_DIR / "result.json"
    if result_path.is_file():
        log(f"This cohort is already complete at {result_path}")
        return

    db = OUTPUT_DIR / "checkpoint.sqlite"
    seeds = list(h2h._game_seeds(SEED, COUNT))
    seed_set = set(seeds)
    openers = {seed: 1 + index % 2 for index, seed in enumerate(seeds)}
    manifest = {
        "schema_version": 1, "model": h2h.PRODUCTION_MODEL,
        "engine_sha256": sha256(Path(h2h.bgbot_cpp.__file__).read_bytes()).hexdigest(),
        "player_a": {"bot": "sage", "eval_level": "truncated1"},
        "player_b": {"bot": "xg", "eval_level": "truncated1"},
        "reference": "sage_2ply_nd", "beta": 1.0, "seed": SEED,
        "sage_rollout_seed": "Random(game_seed XOR 0x5167A19B).getrandbits(31) per decision",
        "variant": "paskogammon", "start_board": list(CONFIG.start_board),
        "opening": {"board_perspective": "scattered side on roll",
                    "seat_order": "Sage starts game 1, then alternate by scheduled game index",
                    "first_roll": "ordinary dice, including doubles", "cube_offer_before_roll": True},
        "rules": {"jacoby": True, "beaver": False, "max_cube_value": CONFIG.max_cube_value,
                  "max_turns": CONFIG.max_turns},
        "game_count": COUNT, "xg_profile": PROFILE,
    }
    with sqlite3.connect(db) as connection:
        connection.executescript("""
            create table if not exists metadata (key text primary key, value text not null);
            create table if not exists games (seed integer primary key, record text not null);
            create table if not exists batches (items integer not null, seconds real not null);
        """)
        prior = connection.execute("select value from metadata where key = 'manifest'").fetchone()
        if prior and json.loads(prior[0]) != manifest:
            raise RuntimeError("Manifest differs from the saved cohort")
        connection.execute("insert or ignore into metadata values ('manifest', ?)", (json.dumps(manifest),))
        finished = {seed for (seed,) in connection.execute("select seed from games")}
    if not finished <= seed_set:
        raise RuntimeError("Saved records include seeds outside the planned cohort")
    log(f"Starting {COUNT - len(finished)} pending games, {len(finished)} committed; "
        f"{STREAMS} game streams and {SAGE_WORKERS} Sage compute workers")

    if finished != seed_set:
        oracle = Oracle(db)
        xg = _QueuedPolicy(oracle)
        cleanup_error = []

        def serve():
            try:
                xg.serve()
            finally:
                try:
                    oracle.stop()
                except Exception as error:
                    cleanup_error.append(error)

        service = Thread(target=serve, name="xg-batch")
        service.start()
        try:
            with ThreadPoolExecutor(max_workers=SAGE_WORKERS, thread_name_prefix="Sage") as compute:
                sage = SagePool(compute)
                runner = Runner(sage, xg, openers)

                def play(seed):
                    record = runner.play(seed)
                    with sqlite3.connect(db) as connection:
                        connection.execute("insert into games values (?, ?)", (seed, json.dumps(record)))
                    return record

                with ThreadPoolExecutor(max_workers=STREAMS, thread_name_prefix="Game") as streams:
                    h2h._parallel_games(streams, (seed for seed in seeds if seed not in finished), STREAMS, play=play)
        finally:
            xg.queue.put(None)
            service.join()
        if cleanup_error:
            raise cleanup_error[0]

    with sqlite3.connect(db) as connection:
        records = {seed: json.loads(record) for seed, record in connection.execute("select * from games")}
        info = json.loads(connection.execute("select value from metadata where key = 'xg'").fetchone()[0])
        rounds, seconds, items = connection.execute("select count(*), sum(seconds), sum(items) from batches").fetchone()
    if records.keys() != seed_set:
        raise RuntimeError("Missing or unexpected completed game seeds")
    ordered = [records[seed] for seed in seeds]
    if any(record["start_player"] != openers[record["seed"]] for record in ordered):
        raise RuntimeError("Saved games do not follow the alternating first-player schedule")
    balanced, by_opener = balanced_estimates(ordered)
    info.update(batch_count=rounds, batch_seconds=seconds, decision_count=items)
    report = dict(manifest, games=ordered, workers=STREAMS, sage_compute_workers=SAGE_WORKERS,
                  xg=info, wall_seconds=monotonic() - START,
                  cpu_timing_scope="H2H game threads and Sage engine workers",
                  summary=h2h._summarize(ordered, external_bot=True),
                  balanced_estimates=balanced, by_opener=by_opener)
    write_json(result_path, report)
    log(f"Finished all {len(ordered)} games in this cohort and wrote result.json")


if __name__ == "__main__":
    main()
