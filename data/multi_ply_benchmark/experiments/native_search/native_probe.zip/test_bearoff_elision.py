from pathlib import Path
common=(Path(__file__).parent/'run_search_probe.py').read_text(encoding='utf-8').split('def run(mode')[0]
exec(common)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.GetCurrentProcess.restype=ctypes.c_void_p
kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),1<<12)
assert type(strategy).__name__=='BearoffStrategy'
data=[]; rng=random.Random(9613)
for repeat in range(3):
    for p in positions:
        arms=['double','single'];rng.shuffle(arms)
        block={}
        for arm in arms:
            dll.search_trial_reset(0,False,0,0,0)
            kw=dict(p['inputs']); kw['owner']=resolve_owner(kw.pop('cube_owner'))
            t=time.perf_counter(); r=cpp.cubeful_probs_and_equity_nply(**kw, strategy=strategy,n_plies=3,n_threads=1,bearoff_db=(engine._bearoff_db if arm=='double' else None))
            elapsed=time.perf_counter()-t
            data.append(dict(repeat=repeat,id=p['id'],arm=arm,seconds=elapsed,result=r))
            block[arm]=r
        assert block['single']==block['double'],p['id']
    print('rep',repeat,flush=True)
out=root/'data/multi_ply_benchmark/experiments/native_search'
import gzip
with gzip.open(out/'bearoff_elision.json.gz','wt') as f:json.dump(data,f)
full=[r['seconds'] for r in data if r['arm']=='double']; single=[r['seconds'] for r in data if r['arm']=='single']
print('wall double',sum(full),'single',sum(single),'median ratio',statistics.median(y/x for x,y in zip(full,single)))
