#include "bgbot/moves.h"
#include <chrono>
#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <algorithm>
#include <functional>
#include <array>
extern "C" { int trial_mode=0; }
int main(int argc,char**argv) {
    std::ifstream input(argv[1]);
    std::vector<bgbot::Board> boards;
    bgbot::Board b;
    while(input>>b[0]){for(int i=1;i<26;i++)if(!(input>>b[i]))return 1;boards.push_back(b);}
    if(boards.empty())return 2;
    std::mt19937 gen(11763);
    std::array<long long,4> times{},doubles{},nd{};
    int rolls=0; long long endpoints=0;
    std::vector<bgbot::Board> outputs[4];
    for(const auto& board:boards) for(int d1=1;d1<=6;++d1) for(int d2=d1;d2<=6;++d2) {
        int modes[4]={0,1,2,3}; std::shuffle(modes,modes+4,gen);
        for(int m:modes) {
            trial_mode=m;
            auto t=std::chrono::steady_clock::now();
            for(int rep=0;rep<4;++rep)bgbot::possible_boards_unsorted(board,d1,d2,outputs[m]);
            auto e=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-t).count();
            times[m]+=e; (d1==d2?doubles:nd)[m]+=e;
        }
        for(int m=1;m<=3;++m)if(outputs[m]!=outputs[0]){std::cerr<<"order/content mismatch "<<rolls;return 4;}
        endpoints+=outputs[0].size(); ++rolls;
    }
    std::cout<<"boards "<<boards.size()<<" rolls "<<rolls<<" endpoints "<<endpoints<<" exact sequence all 4 modes\n";
    for(int m=0;m<4;++m)std::cout<<m<<" ns "<<times[m]<<" doubles "<<doubles[m]<<" nondoubles "<<nd[m]<<"\n";
}
