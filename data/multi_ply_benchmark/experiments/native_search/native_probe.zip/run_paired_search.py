from pathlib import Path
common=(Path(__file__).parent/'run_search_probe.py').read_text(encoding='utf-8').split('def run(mode')[0]
exec(common.replace('build/multi_ply_engine','build/multi_ply_anchor'))
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.GetCurrentProcess.restype=ctypes.c_void_p
kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
if not kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),1<<12): raise ctypes.WinError(ctypes.get_last_error())
import random
rng=random.Random(13579)
out=root/'logs/multi_ply_search'
stats=[]
for itr in range(3):
    for i,p in enumerate(positions):
        modes=[0,1,2,3,4,8,15,16,19]
        rng.shuffle(modes)
        block=[]
        for m in modes:
            dll.search_trial_reset(m,True,0,0,0)
            t=time.perf_counter(); res=call(p); elapsed=time.perf_counter()-t
            block.append(dict(mode=m,id=p['id'],rep=itr,sec=elapsed,res=res,ns=[dll.search_trial_ns(j) for j in range(5)]))
        stats+=block
    (out/'paired_search_trials.json').write_text(json.dumps(stats))
    print('pass',itr,flush=True)
    for m in sorted(modes):
        rows=[r for r in stats if r['mode']==m]
        base=[r for r in stats if r['mode']==0]
        dp=max(abs(x-y) for a,b in zip(rows,base) for x,y in zip(a['res']['probs'],b['res']['probs']))
        de=max(abs(a['res']['equity']-b['res']['equity']) for a,b in zip(rows,base))
        print(m, sum(r['sec'] for r in rows),[round(sum(r['ns'][i] for r in rows)/1e9,3) for i in range(5)],'ratioMedian',round(statistics.median(a['sec']/b['sec'] for a,b in zip(rows,base)),4),'delta',dp,de,flush=True)

