"""Measure the isolated native 3-ply tree on every cube-set board using one thread and a fresh TT for each pass."""
from pathlib import Path
import ctypes, sys, json, time, statistics, random, hashlib
root=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(root/'build/multi_ply_engine'),str(root/'python')]
import bgbot_cpp as cpp
from bgsage import BgBotAnalyzer
from bgsage.analyzer import resolve_owner
dll = ctypes.CDLL(cpp.__file__)
dll.search_trial_ns.restype=ctypes.c_uint64
dll.search_trial_count.restype=ctypes.c_uint64
positions=json.loads((root/'data/multi_ply_benchmark/cube_action.json').read_text())['positions']
engine=BgBotAnalyzer(eval_level='3ply',parallel_threads=2)
strategy=engine._analyzer._inner._strategy_1ply
def call(pos, ply=3):
    kw=dict(pos['inputs']); kw['owner']=resolve_owner(kw.pop('cube_owner'))
    return cpp.cubeful_probs_and_equity_nply(**kw, strategy=strategy,n_plies=ply,n_threads=1,bearoff_db=engine._bearoff_db)
def run(mode,profile=False):
    dll.search_trial_reset(mode,profile,0,0,0)
    t=time.perf_counter()
    result=[call(p) for p in positions]
    elapsed=time.perf_counter()-t
    digest=hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()
    return {'mode':mode,'profile':profile,'seconds':elapsed,'digest':digest,
            'region_ns':[dll.search_trial_ns(i) for i in range(5)],
            'region_counts':[dll.search_trial_count(i) for i in range(5)]}
out=root/'logs/multi_ply_search'
out.mkdir(parents=True,exist_ok=True)
history=[]
def log(r):
    history.append(r); print(r, flush=True)
    (out/'kernel_trials.json').write_text(json.dumps(history,indent=2))
log(run(0,True))
rng=random.Random(639)
for _ in range(4):
    modes=[0,1,2,3,4,8,15];rng.shuffle(modes)
    for m in modes:log(run(m))
for change in ('filter','deep'):
    cold_diff=0; interleaved_equal=0
    for p in positions:
        a_ctx=(0,2,0) if change=='filter' else (1,2,0)
        b_ctx=(0,2,1) if change=='filter' else (1,3,0)
        dll.search_trial_reset(0,False,*a_ctx); a=call(p,2)
        dll.search_trial_context(*b_ctx); warm_b=call(p,2)
        dll.search_trial_reset(0,False,*b_ctx); b=call(p,2)
        cold_diff+=a!=b
        dll.search_trial_context(*a_ctx); warm_a=call(p,2)
        interleaved_equal+=warm_a==a and warm_b==b
    print('TT test',change,cold_diff,interleaved_equal,flush=True)
    assert cold_diff>0 and interleaved_equal==len(positions)
