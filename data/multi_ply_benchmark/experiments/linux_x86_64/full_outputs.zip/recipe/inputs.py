"""Fingerprint source and fixtures, without touching an existing build."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
COMMIT="139427d826dd67798226e7d23c003c90315306ba"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    original=HERE/"original"
    tree=subprocess.check_output(["git","-C",str(ROOT),"ls-tree","-r","-z",COMMIT,"cpp","python"])
    files={}
    for row in tree.rstrip(b"\0").split(b"\0"):
        _,_,path=row.partition(b"\t")
        mode,kind,obj=row[:row.index(b"\t")].split()
        if kind!=b"blob": raise ValueError(row)
        name=path.decode()
        data=(original/name).read_bytes().replace(b"\r\n",b"\n")
        blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        if blob!=obj.decode(): raise ValueError(f"Frozen original mismatch: {name}")
        files[name]=blob
    state={"commit":COMMIT,"verified_original_blobs":len(files),"changes_from_original":{}}
    for k in files:
        if Path(k).suffix not in (".cpp",".h",".py",".txt"): continue
        old,new=original/k,ROOT/k
        if not new.exists(): continue
        digest=lambda p: hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()
        a,b=digest(old),digest(new)
        if a!=b:state["changes_from_original"][k]=dict(original_sha256=a,final_sha256=b)
    runtime=HERE/"runtime_original"
    if not runtime.exists():
        shutil.copytree(original/"python",runtime/"python")
    # Developers on Windows may not have symlink privileges. build.sh creates
    # the read-only asset symlink from inside the Ubuntu instance.
    fixtures=[ROOT/"build/cpu_feature_masks/all.bin", ROOT/"build/nn_trials/corpus.txt",
              ROOT/"data/multi_ply_benchmark/checker_play.json",ROOT/"data/multi_ply_benchmark/cube_action.json",
              ROOT/"data/bearoff_1sided.db"]
    state["fixtures_sha256"]={p.relative_to(ROOT).as_posix():sha(p) for p in fixtures}
    (HERE/"input_identity.json").write_text(json.dumps(state,indent=2)+"\n",encoding="utf-8")
    print(len(files),"original Git blobs verified,",len(state["changes_from_original"]),"source changes")

if __name__=="__main__":main()
