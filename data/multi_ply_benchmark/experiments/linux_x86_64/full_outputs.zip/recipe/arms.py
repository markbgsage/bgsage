"""Run complete, fresh-process Linux public benchmarks in either order."""
import argparse
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]

def run(arm,threads,apis,output):
    ext=next((HERE/(arm+"-gcc")).glob("bgbot_cpp*.so"))
    native=HERE/"original" if arm=="original" else ROOT
    python=HERE/"runtime_original/python" if arm=="original" else ROOT/"python"
    subprocess.run([sys.executable,"-B",str(ROOT/"scripts/benchmark_multi_ply.py"),
                    "--levels","3ply","--extension",str(ext),"--native-source",str(native),
                    "--python-dir",str(python),"--threads",str(threads),"--apis",*apis,
                    "--output",str(output)],cwd=ROOT,check=True)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--threads",required=True,type=int)
    p.add_argument("--arms",nargs="+",choices=("original","final"),default=("original","final"))
    p.add_argument("--apis",nargs="+",default=("checker_play","cube_action","post_move_analytics"))
    p.add_argument("--directory",required=True)
    a=p.parse_args()
    dest=(HERE/a.directory).resolve()
    if not dest.is_relative_to(HERE):raise ValueError("use private project output")
    dest.mkdir(exist_ok=True)
    for arm in a.arms:run(arm,a.threads,a.apis,dest/arm)
