"""Recover the original Linux 244-float input for each real sibling."""
from pathlib import Path
import struct
here=Path(__file__).resolve().parent
root=here.parents[2]
cases=[]
for line in (root/"build/nn_trials/corpus.txt").read_text().splitlines():
    name,*points=line.split()
    cases.append((name,struct.pack("<26i",*map(int,points))))
required={b for _,b in cases}
found={}
with (root/"build/cpu_feature_masks/all.bin").open("rb") as boards,(here/"original-gcc/features.bin").open("rb") as x:
    i=0
    while b:=boards.read(104):
        if b in required and b not in found:
            x.seek((i*440+196)*4)
            found[b]=x.read(244*4)
        i+=1
if found.keys()!=required:
    raise ValueError(f"Missing {len(required-found.keys())} siblings")
with (here/"shared-inputs.bin").open("wb") as f:
    last=None
    for name,b in cases:
        f.write(bytes([name!=last]))
        f.write(found[b])
        last=name
print(len(cases),"original Linux sibling embeddings")
