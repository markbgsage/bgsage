#!/usr/bin/env bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
for arm in original final; do
    for operation in configure compile probes; do
        start=$(date +%s)
        printf '%s %s %s start\n' "$(date -Iseconds)" "$arm" "$operation"
        bash "$work/toolchain.sh" "$operation" "$arm" 2>&1 | tee "$work/$arm-$operation.log"
        printf '%s %s %s elapsed=%ss\n' "$(date -Iseconds)" "$arm" "$operation" "$(( $(date +%s)-start ))"
    done
done
