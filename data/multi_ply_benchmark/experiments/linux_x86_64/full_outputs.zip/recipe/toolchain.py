"""Create a project-local compiler from the Ubuntu installation's signed package index."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urljoin
from urllib.request import urlopen

HERE = Path(__file__).resolve().parent
CACHE = HERE / "packages"
SYSROOT = HERE / "toolchain"
PACKAGES = """cpp-15-x86-64-linux-gnu gcc-15-x86-64-linux-gnu g++-15-x86-64-linux-gnu
gcc-15-base libisl23 libmpc3 libgcc-15-dev libstdc++-15-dev libc6-dev linux-libc-dev
libpython3.14-dev make cmake cmake-data libuv1t64 libarchive13t64 libjsoncpp26 librhash1""".split()

def metadata(package):
    policy = subprocess.check_output(["apt-cache","policy",package],text=True)
    version = re.search(r"^\s*Candidate: (.+)$",policy,re.M).group(1)
    if version=="(none)":
        raise RuntimeError(f"No authenticated candidate for {package}")
    record = subprocess.check_output(["apt-cache","show",f"{package}={version}"],text=True)
    fields = dict(line.split(": ",1) for line in record.splitlines() if ": " in line and not line.startswith(" "))
    if not fields["Filename"].startswith("pool/"):
        raise RuntimeError(fields["Filename"])
    return {"package":package,"version":version,"filename":fields["Filename"],
            "sha256":fields["SHA256"],"bytes":int(fields["Size"])}

def fetch(item):
    target = CACHE / Path(item["filename"]).name
    if target.exists() and hashlib.file_digest(target.open("rb"),"sha256").hexdigest()==item["sha256"]:
        return target
    for mirror in ("https://archive.ubuntu.com/ubuntu/","https://security.ubuntu.com/ubuntu/"):
        try:
            with urlopen(urljoin(mirror,item["filename"]),timeout=30) as response:
                data = response.read()
            if len(data)!=item["bytes"] or hashlib.sha256(data).hexdigest()!=item["sha256"]:
                raise RuntimeError(f"Signed index size/SHA mismatch: {item['package']}")
            target.write_bytes(data)
            return target
        except OSError as error:
            print(f"{mirror} {item['package']}: {error}",flush=True)
    raise RuntimeError(f"Could not retrieve signed package: {item['package']}")

def main():
    CACHE.mkdir(exist_ok=True)
    SYSROOT.mkdir(exist_ok=True)
    items=[metadata(p) for p in PACKAGES]
    (HERE/"ubuntu-packages.json").write_text(json.dumps(items,indent=2)+"\n")
    print(len(items),"packages",sum(i["bytes"] for i in items),"bytes",flush=True)
    if sys.argv[1]=="inspect":return
    for item in items:
        data=fetch(item)
        if sys.argv[1]=="extract":
            subprocess.run(["dpkg-deb","-x",str(data),str(SYSROOT)],check=True)
        print(item["package"],item["bytes"],flush=True)
    if sys.argv[1]!="extract":return
    for path,target in [(SYSROOT/"lib","usr/lib"),(SYSROOT/"lib64","usr/lib64")]:
        if not path.exists() and not path.is_symlink():path.symlink_to(target)
    local=SYSROOT/"usr/lib/x86_64-linux-gnu"
    for path in Path("/usr/lib/x86_64-linux-gnu").glob("*.so*"):
        dest=local/path.name
        if path.is_file() and not dest.exists() and not dest.is_symlink():dest.symlink_to(path)
    (SYSROOT/"usr/lib64").mkdir(exist_ok=True)
    loader=SYSROOT/"usr/lib64/ld-linux-x86-64.so.2"
    if not loader.exists() and not loader.is_symlink():
        loader.symlink_to("/lib64/ld-linux-x86-64.so.2")

if __name__=="__main__":
    main()
