"""Compare the complete Linux public dataclasses and the native probe floats."""
from array import array
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]

def floats(a,b,width):
    if a.stat().st_size!=b.stat().st_size or a.stat().st_size%(4*width):
        raise ValueError("mismatched buffer shape")
    worst=Counter()
    count=Counter()
    location={}
    total=0
    with a.open("rb") as left,b.open("rb") as right:
        while x:=left.read(width*4*128):
            y=right.read(len(x))
            n=len(x)//4
            if x!=y:
                xv=array("f");xv.frombytes(x)
                yv=array("f");yv.frombytes(y)
                for j,(u,v) in enumerate(zip(xv,yv)):
                    if not math.isfinite(u) or not math.isfinite(v):raise ValueError("nonfinite native value")
                    delta=abs(u-v)
                    if delta:
                        field=j%width
                        count[field]+=1
                        if delta>worst[field]:
                            worst[field]=delta
                            location[field]=[(total+j)//width,u,v]
            total+=n
    return dict(floats=total,rows=total//width,differing=sum(count.values()),max_abs=max(worst.values(),default=0),
                by_column={k:dict(n=count[k],worst=worst[k],example=location[k]) for k in sorted(count)})

def loads(p):
    return {(r["api"],r["position_id"]):r for r in map(json.loads,p.read_bytes().splitlines())}

def flatten(v,path=()):
    if isinstance(v,dict):
        for k,w in v.items():yield from flatten(w,path+(k,))
    elif isinstance(v,list):
        for k,w in enumerate(v):yield from flatten(w,path+(k,))
    else:yield path,v

def outputs(left,right):
    a,b=loads(left),loads(right)
    if a.keys()!=b.keys():raise ValueError("public cases differ")
    rank=Counter()
    numeric=defaultdict(lambda:[0,0,0.,0.,0])
    shape=[]
    exact=Counter()
    actions=[]
    times=defaultdict(lambda:[0.,0.])
    for case,r in a.items():
        api,id=case
        v,w=r["analytics"],b[case]["analytics"]
        if r["inputs"]!=b[case]["inputs"]:raise ValueError(case)
        exact[api]+=v==w
        times[api][0]+=r["elapsed_seconds"]
        times[api][1]+=b[case]["elapsed_seconds"]
        if api=="checker_play":
            x,y=([tuple(m["board"]) for m in z["moves"]] for z in (v,w))
            rank["order_changes"]+=x!=y
            rank["picked_changes"]+=x[0]!=y[0]
            rank["different_lists"]+=set(x)!=set(y)
            v={**v,"moves":{tuple(m["board"]):m for m in v["moves"]}}
            w={**w,"moves":{tuple(m["board"]):m for m in w["moves"]}}
        elif api=="cube_action" and v["optimal_action"]!=w["optimal_action"]:
            actions.append([id,v["optimal_action"],w["optimal_action"]])
        x,y=dict(flatten(v)),dict(flatten(w))
        if x.keys()!=y.keys():shape.append([api,id,"different paths"])
        for key in x.keys() & y.keys():
            f,g=x[key],y[key]
            if isinstance(f,float) and isinstance(g,(float,int)):
                if not math.isfinite(f) or not math.isfinite(g):raise ValueError(case)
                label=str(key[-1])
                fields=numeric[api,label]
                d=abs(f-g)
                fields[0]+=1
                fields[1]+=f!=g
                fields[2]+=d
                fields[3]=max(fields[3],d)
                fields[4]+=d>(.0025 if "probs" in key else .005)
            elif f!=g:
                shape.append([api,id,repr(key),f,g])
    return dict(cases=len(a),equal_full_outputs=dict(exact),checker_moves=rank,action_changes=actions,
                structure_or_nonnumeric=shape,elapsed_seconds=times,
                numeric=[dict(api=k[0],field=k[1],n=v[0],differing=v[1],mean_abs=v[2]/v[0],max_abs=v[3],above=v[4])
                         for k,v in sorted(numeric.items())])

if __name__=="__main__":
    if sys.argv[1]=="native":
        info={k:floats(HERE/"original-gcc"/f"{k}.bin",HERE/"final-gcc"/f"{k}.bin",w)
              for k,w in (("features",440),("nn",5))}
    else:
        info=outputs(Path(sys.argv[2]),Path(sys.argv[3]))
    (HERE/sys.argv[-1]).write_text(json.dumps(info,indent=2)+"\n")
    if "numeric" in info:
        print("full equality",dict(info["equal_full_outputs"]),"rank",dict(info["checker_moves"]),
              "material fields",sum(v["above"] for v in info["numeric"]))
    else:print({k:{n:v[n] for n in ("floats","differing","max_abs")} for k,v in info.items()})
