#!/usr/bin/env bash
set -euo pipefail
work="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
engine="$(cd "$work/../../.." && pwd)"
sysroot="$work/toolchain"
gcc_home="$sysroot/usr/lib/gcc/x86_64-linux-gnu/15"
export TMPDIR="$work/tmp"
export LD_LIBRARY_PATH="$sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PATH="$sysroot/usr/bin:/usr/local/bin:/usr/bin:/bin"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONNOUSERSITE=1
mkdir -p "$TMPDIR"

# Drive the standard Ubuntu GCC with its relocated cc1plus and system headers.
# System binutils and glibc runtimes are from the same distro image.
cxx="$sysroot/usr/bin/x86_64-linux-gnu-g++-15"
cxx_flags=("--sysroot=$sysroot" "-B$gcc_home/" "-B$sysroot/usr/libexec/gcc/x86_64-linux-gnu/15/" "-B$sysroot/usr/lib/x86_64-linux-gnu/"
    -isystem "$sysroot/usr/include/c++/15" -isystem "$sysroot/usr/include/x86_64-linux-gnu/c++/15"
    -isystem "$sysroot/usr/include/c++/15/backward")
printf -v flags '%q ' "${cxx_flags[@]}"
export CXX="$cxx"
cmake_args=(-G "Unix Makefiles" "-DCMAKE_MAKE_PROGRAM=$sysroot/usr/bin/make"
    "-DCMAKE_CXX_COMPILER=$cxx" "-DCMAKE_CXX_FLAGS=$flags" -DCMAKE_BUILD_TYPE=Release
    -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DBGBOT_BUILD_APPS=OFF -DPYBIND11_FINDPYTHON=ON
    "-DPython_EXECUTABLE=/usr/bin/python3" "-DPython_INCLUDE_DIR=$sysroot/usr/include/python3.14"
    "-DPython_LIBRARY=/usr/lib/x86_64-linux-gnu/libpython3.14.so.1.0"
    "-Dpybind11_DIR=$engine/build/multi_ply_tools/pybind11/share/cmake/pybind11")

if [[ "$1" == inspect ]]; then
    "$cxx" --version | head -n 1
    "$sysroot/usr/bin/cmake" --version | head -n 1
    command -v ld as
    "$cxx" "${cxx_flags[@]}" -print-prog-name=cc1plus
    "$cxx" "${cxx_flags[@]}" -print-file-name=crtbeginS.o
    "$cxx" "${cxx_flags[@]}" -print-file-name=libstdc++.so
    python3 -c 'import sysconfig; print(sysconfig.get_config_var("EXT_SUFFIX"))'
    exit
fi
if [[ "$1" == smoke ]]; then
    echo '#include <iostream>
    #include <immintrin.h>
    int main() {std::cout << sizeof(__m256) << std::endl;}' > "$work/toolchain-smoke.cpp"
    "$cxx" "${cxx_flags[@]}" -std=c++17 -mavx2 -mfma "$work/toolchain-smoke.cpp" -o "$work/toolchain-smoke"
    "$work/toolchain-smoke"
    exit
fi
arm="$2"
case "$arm" in
    original) src="$work/original" ;;
    final) src="$engine" ;;
    *) echo "Unknown source $arm" >&2; exit 2 ;;
esac
out="$work/$arm-gcc"
if [[ "$1" == configure ]]; then
    "$sysroot/usr/bin/cmake" -S "$src" -B "$out" "${cmake_args[@]}"
    [[ -e "$work/runtime_original/models" ]] || ln -s "$engine/models" "$work/runtime_original/models"
elif [[ "$1" == compile ]]; then
    "$sysroot/usr/bin/cmake" --build "$out" --target bgbot_cpp --parallel 2
elif [[ "$1" == probes ]]; then
    "$cxx" "${cxx_flags[@]}" -std=c++17 -O3 -mavx2 -mfma -I"$src/cpp/include" \
        "$work/probe.cpp" "$out/libbgbot_lib.a" -pthread -o "$out/probe"
    "$out/probe" "$engine/build/cpu_feature_masks/all.bin" "$engine/build/nn_trials/corpus.txt" \
        "$engine/models/sl_s9_att_race.weights.best" "$out/features.bin" "$out/nn.bin"
elif [[ "$1" == shared-inputs ]]; then
    "$cxx" "${cxx_flags[@]}" -std=c++17 -O3 -mavx2 -mfma -I"$src/cpp/include" \
        "$work/same_nn.cpp" "$out/libbgbot_lib.a" -pthread -o "$out/same_nn"
    "$out/same_nn" "$work/shared-inputs.bin" "$engine/models/sl_s9_att_race.weights.best" "$out/same_nn.bin"
else
    echo "Unknown command $1" >&2; exit 2
fi
