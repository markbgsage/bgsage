// SPDX-License-Identifier: MPL-2.0
#include "bgbot/encoding.h"
#include "bgbot/neural_net.h"
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace bgbot;

template<class T> void emit(std::ofstream& out,const T& values) {
    out.write(reinterpret_cast<const char*>(values.data()),sizeof(typename T::value_type)*values.size());
}
int main(int argc,char**argv) {
    if(argc!=6)return 1;
    std::ifstream board_file(argv[1],std::ios::binary), checks(argv[2]);
    std::ofstream feature_file(argv[4],std::ios::binary), net_file(argv[5],std::ios::binary);
    if(!board_file || !checks || !feature_file || !net_file)return 2;
    Board board;
    size_t boards=0,siblings=0,shapes=0;
    while(board_file.read(reinterpret_cast<char*>(board.data()),sizeof(board))) {
        emit(feature_file,compute_tesauro_inputs(board));
        emit(feature_file,compute_extended_contact_inputs(board));
        ++boards;
    }
    NeuralNetwork model(400,244);
    if(!model.load_weights(argv[3]))return 3;
    float base[400],saved[244];
    std::string id,previous;
    while(checks>>id) {
        for(int& point:board)if(!(checks>>point))return 4;
        const auto inputs=compute_extended_contact_inputs(board);
        emit(net_file,id!=previous?model.forward_save_base(inputs.data(),base,saved):
                                   model.forward_from_base(inputs.data(),base,saved));
        previous=id;
        ++siblings;
    }
    for(int ni:{3,17,196,244,301})for(int nh:{4,7,16,24,100,400,513}) {
        NeuralNetwork shape(nh,ni,.1f,17);
        std::vector<float> x(ni),other(ni),weights(nh),anchor(ni);
        for(int j=0;j<ni;++j)x[j]=std::sin(j+.25f)*.75f;
        shape.forward_save_base(x.data(),weights.data(),anchor.data());
        for(int changed:{0,1,3,4,7,15,16,31,63,64,65,2000}) {
            other=x;
            for(int j=0;j<ni && j<changed;++j)other[(17*j+1)%ni]+=.37f*(j%5-2);
            emit(net_file,shape.forward_from_base(other.data(),weights.data(),anchor.data()));
            ++shapes;
        }
    }
    std::cout<<"boards "<<boards<<" siblings "<<siblings<<" shape_cases "<<shapes<<"\n";
    return !feature_file || !net_file || boards==0 || siblings!=1422;
}
