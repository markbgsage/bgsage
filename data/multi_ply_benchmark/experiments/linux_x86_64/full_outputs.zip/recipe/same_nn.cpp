#include "bgbot/neural_net.h"
#include <array>
#include <fstream>
#include <iostream>
using namespace bgbot;
int main(int argc,char**argv) {
    if(argc!=4)return 1;
    std::ifstream inputs(argv[1],std::ios::binary);
    std::ofstream out(argv[3],std::ios::binary);
    NeuralNetwork net(400,244);
    if(!net.load_weights(argv[2]))return 2;
    float base[400],saved[244];
    std::array<float,244> row;
    char anchor;
    size_t n=0;
    while(inputs.get(anchor)) {
        if(!inputs.read(reinterpret_cast<char*>(row.data()),sizeof(row)))return 3;
        auto v=anchor?net.forward_save_base(row.data(),base,saved):net.forward_from_base(row.data(),base,saved);
        out.write(reinterpret_cast<const char*>(v.data()),sizeof(v));
        ++n;
    }
    std::cout<<n<<" shared-input rows\n";
    return n!=1422;
}
