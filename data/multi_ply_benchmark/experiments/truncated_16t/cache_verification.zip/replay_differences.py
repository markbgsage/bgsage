"""Repeat only the benchmark calls whose original and optimized outputs differed."""
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import subprocess
import sys

RUN = Path(__file__).resolve().parent
ENGINE = RUN.parents[1]
sys.path.insert(0, str(ENGINE / "scripts"))
from benchmark_multi_ply import load_engine

def digest(analytics):
    return hashlib.sha256(json.dumps(analytics, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def cases():
    found = []
    for level in ("1T", "2T", "3T"):
        def read(arm):
            directory = RUN if arm == "baseline" else RUN.parent / "truncated_benchmark_fixed_16t"
            return [json.loads(line) for line in (directory / f"{level}-{arm}" / "results.jsonl").read_bytes().splitlines()]
        for left, right in zip(read("baseline"), read("candidate"), strict=True):
            focus = (level, left["api"], left["position_id"])
            if left["analytics"] != right["analytics"] or focus in (
                    ("1T", "cube_action", "cube-money-anchoring-07"),
                    ("2T", "checker_play", "checker-money-priming-10")):
                row = {key: left[key] for key in ("api", "level", "position_id", "inputs", "seed")}
                found.append(dict(**row, baseline=digest(left["analytics"]), candidate=digest(right["analytics"])))
    return found

def replay(arm, threads):
    directory = RUN if arm == "baseline" else RUN.parent / "truncated_benchmark_fixed_16t"
    config = json.loads((directory / f"1T-{arm}" / "metadata.json").read_bytes())
    python = "logs/multi_ply_rollout_truth/frozen/python" if arm == "baseline" else "python"
    package, _ = load_engine(ENGINE / config["extension"]["path"], ENGINE / python)
    weights = package.WeightConfig.from_model("stage11")
    result = []
    for case in cases():
        analyzer = package.BgBotAnalyzer(weights=weights, eval_level=case["level"], cubeful=True,
                    parallel_threads=threads, bearoff_db=str(ENGINE / "data/bearoff_1sided.db"))
        repeats = []
        for _ in range(1 if threads == 1 else 3):
            analyzer.set_seed(case["seed"])
            repeats.append(asdict(getattr(analyzer, case["api"])(**case["inputs"])))
        result.append(dict(**case, arm=arm, threads=threads, hashes=list(map(digest, repeats)), full_analytics=repeats))
    return result

if __name__ == "__main__":
    if len(sys.argv) == 3:
        print(json.dumps(replay(sys.argv[1], int(sys.argv[2])), separators=(",", ":")))
    else:
        output = []
        for arm, threads in (("candidate", 16), ("candidate", 1), ("baseline", 16)):
            output.extend(json.loads(subprocess.check_output([sys.executable, "-B", __file__, arm, str(threads)])))
        (RUN / "replay.json").write_text(json.dumps(output, separators=(",", ":")) + "\n", encoding="utf-8")
        for row in output:
            print(row["level"], row["api"], row["position_id"], row["arm"], row["threads"],
                  ["original" if h == row["baseline"] else "optimized" if h == row["candidate"] else h[:10] for h in row["hashes"]])
