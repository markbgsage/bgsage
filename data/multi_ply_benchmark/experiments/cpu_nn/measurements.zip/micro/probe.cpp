#include "bgbot/encoding.h"
#include "bgbot/neural_net.h"
#include <windows.h>
#include <array>
#include <chrono>
#include <cmath>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
using namespace bgbot;
struct Sample {bool first; std::array<float,244> x;};
int main(int argc,char**argv) {
    if(argc!=4 || !SetProcessAffinityMask(GetCurrentProcess(),DWORD_PTR(1)<<8)) return 1;
    std::ifstream dataset(argv[1]);
    std::ofstream stream(argv[3],std::ios::binary);
    std::string id,last;
    std::vector<Sample> samples;
    while(dataset>>id) {
        Board b;
        for(int& n:b)dataset>>n;
        samples.push_back({id!=last,compute_extended_contact_inputs(b)});
        last=id;
    }
    if(samples.empty()||!stream)return 2;
    NeuralNetwork net(400,244);
    if(!net.load_weights(argv[2]))return 3;
    float base[400], prev[244];
    float guard=0;
    for(int rep=-1;rep<6;++rep) {
        auto start=std::chrono::steady_clock::now();
        int passes=rep<0?1:100;
        for(int pass=0;pass<passes;++pass) for(const auto& s:samples) {
            auto y=s.first?net.forward_save_base(s.x.data(),base,prev):net.forward_from_base(s.x.data(),base,prev);
            guard+=y[pass%5];
            if(rep<0)stream.write(reinterpret_cast<const char*>(y.data()),sizeof(y));
        }
        if(rep>=0)std::cout<<std::fixed<<std::setprecision(2)
            <<std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-start).count()
                /(passes*samples.size())<<" ";
    }
    std::cout<<"sink="<<guard<<"\n";
    // Arbitrary supported shapes including SIMD tails, >512 hidden weights,
    // long delta sequences, an unchanged sibling, and non-vectorized inputs.
    for(int n:{3,17,196,244,301})for(int nh:{4,7,16,24,100,400,513}) {
        NeuralNetwork other(nh,n,.1f,17);
        std::vector<float> x(n),y(n),save(nh),anchor(n);
        for(int i=0;i<n;++i)x[i]=std::sin(i+.25f)*.75f;
        other.forward_save_base(x.data(),save.data(),anchor.data());
        for(int k:{0,1,3,4,7,15,16,31,63,64,65,2000}) {
            y=x;
            for(int i=0;i<n && i<k;++i)y[(17*i+1)%n]+=.37f*(i%5-2);
            auto value=other.forward_from_base(y.data(),save.data(),anchor.data());
            stream.write(reinterpret_cast<const char*>(value.data()),sizeof(value));
        }
    }
}
