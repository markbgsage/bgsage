"""Paired public CPU calls with fixed benchmark seeds and an alternate-arm order."""
import argparse
from collections import defaultdict
from dataclasses import asdict
from hashlib import sha256
import json
from multiprocessing import get_context
import os
from pathlib import Path
from random import Random
import subprocess
import sys
from time import perf_counter
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_multi_ply import load_engine


def worker(pipe, arm, level, binary):
    width, memo = arm.split("-")
    os.environ["BGSAGE_BENCH_TRIAL_CHUNK"] = width
    os.environ["BGSAGE_BENCH_TRIAL_TREE"] = memo
    engine, _ = load_engine(binary, binary.parent / "python")
    analyzer = engine.BgBotAnalyzer(weights=engine.WeightConfig.from_model("stage11"),
        eval_level=level, cubeful=True, parallel_threads=16,
        bearoff_db=str(ROOT / "data/bearoff_1sided.db"))
    while item := pipe.recv():
        api, row = item
        args = row["post_move_inputs"] if api=="post_move_analytics" else row["inputs"]
        seed = int.from_bytes(sha256(("truncated-benchmark-v1:"+row["source"]["key"]).encode()).digest()[:4],"big")
        analyzer.set_seed(seed)
        tic = perf_counter()
        result = getattr(analyzer,api)(**args)
        toc = perf_counter()
        pipe.send((toc-tic, asdict(result),seed))


def cases(api, offset):
    file = "checker_play" if api=="checker_play" else "cube_action"
    pos = json.loads((ROOT/"data/multi_ply_benchmark"/(file+".json")).read_bytes())["positions"]
    groups = defaultdict(list)
    for row in pos:
        groups[(row["mode"],row["game_plan"])].append(row)
    return [v[offset] for v in groups.values()]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--arm",default="dispatch_tree")
    p.add_argument("--levels",nargs="+",default=["truncated1","truncated2","truncated3"])
    p.add_argument("--widths",nargs="+",default=["8","1","2","4"])
    p.add_argument("--tree-width",default="8")
    p.add_argument("--offset",type=int,default=0)
    p.add_argument("--output",type=Path,required=True)
    cfg=p.parse_args()
    out=cfg.output
    out.mkdir(parents=True,exist_ok=False)
    binary=next((ROOT/"build/truncated_pass2"/cfg.arm).glob("bgbot_cpp.*.so"))
    (out/"metadata.json").write_text(json.dumps(dict(threads=16,sha256=sha256(binary.read_bytes()).hexdigest(),
        args={**vars(cfg),"output":str(out)},source_commit=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()),indent=2))
    for level in cfg.levels:
        arms=[w+"-0" for w in cfg.widths]
        if level=="truncated3": arms.append(cfg.tree_width+"-1")
        jobs=[]
        for api in ("checker_play","cube_action","post_move_analytics"):
            jobs.extend((api,row) for row in cases(api,cfg.offset))
        Random(1303+cfg.offset).shuffle(jobs)
        processes=[]
        pipes={}
        ctx=get_context("spawn")
        with ZipFile(out/(level+".zip"),"x",ZIP_DEFLATED,compresslevel=5) as z:
            with z.open("results.jsonl","w") as f:
                try:
                    for arm in arms:
                        parent,child=ctx.Pipe()
                        proc=ctx.Process(target=worker,args=(child,arm,level,binary))
                        proc.start()
                        child.close()
                        processes.append(proc)
                        pipes[arm]=parent
                        parent.send(("cube_action",cases("cube_action",9)[0]))
                        parent.recv()
                    totals=defaultdict(float); full_equal=0; compared=0
                    for i,(api,row) in enumerate(jobs):
                        order=arms[i%len(arms):]+arms[:i%len(arms)]
                        results={}
                        for arm in order:
                            pipes[arm].send((api,row))
                            elapsed,analytics,seed=pipes[arm].recv()
                            results[arm]=analytics
                            record=dict(level=level,api=api,arm=arm,id=row["id"],source=row["source"],mode=row["mode"],game_plan=row["game_plan"],
                                inputs=(row["post_move_inputs"] if api=="post_move_analytics" else row["inputs"]),seed=seed,seconds=elapsed,analytics=analytics)
                            f.write((json.dumps(record,separators=(",",":"))+"\n").encode())
                            totals[arm]+=elapsed
                        for arm in arms[1:]:
                            compared+=1
                            full_equal+=(results[arm]==results[arms[0]])
                    print(level,dict(totals),full_equal,compared,flush=True)
                    (out/(level+".json")).write_text(json.dumps(dict(seconds=totals,equal=full_equal,comparisons=compared),indent=2))
                finally:
                    for pipe in pipes.values():
                        try: pipe.send(None)
                        except (BrokenPipeError,EOFError): pass
                        pipe.close()
                    for proc in processes:
                        proc.join(timeout=5)
                        if proc.is_alive(): proc.terminate()

if __name__=="__main__": main()
