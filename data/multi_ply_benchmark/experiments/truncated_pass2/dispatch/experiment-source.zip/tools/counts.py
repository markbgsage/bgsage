"""Collect 2-ply cross-worker table hit counts separately from dispatch timings."""
from dataclasses import asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile
from sweep import ROOT, cases, load_engine

arm=ROOT/"build/truncated_pass2/dispatch_tree"
out=Path(sys.argv[1])
out.mkdir(parents=True,exist_ok=True)
os.environ.update(BGSAGE_BENCH_TRIAL_CHUNK="8", BGSAGE_BENCH_TRIAL_TREE="1", BGSAGE_BENCH_TREE_COUNTS="1")
binary=next(arm.glob("bgbot_cpp.*.so"))
engine,_=load_engine(binary,arm/"python")
analyzer=engine.BgBotAnalyzer(weights=engine.WeightConfig.from_model("stage11"),eval_level="truncated3",cubeful=True,
                              parallel_threads=len(os.sched_getaffinity(0)),bearoff_db=str(ROOT/"data/bearoff_1sided.db"))
counts=[]
with ZipFile(out/"count-outputs.zip","x",ZIP_DEFLATED) as archive:
    for row in cases("cube_action",1):
        de=sha256(("truncated-benchmark-v1:"+row["source"]["key"]).encode()).digest()
        seed=int.from_bytes(de[:4],"big")
        analyzer.set_seed(seed)
        original=os.dup(2)
        with (out/"worker_counts.tmp").open("wb") as err:
            try:
                os.dup2(err.fileno(),2)
                result=asdict(analyzer.cube_action(**row["inputs"]))
            finally:
                os.dup2(original,2)
                os.close(original)
        raw=(out/"worker_counts.tmp").read_text()
        match=re.findall(r"trial_tree probes (\d+) hits (\d+) inserts (\d+) bytes (\d+)",raw)
        assert len(match)==1, raw
        probes,hits,inserts,size=map(int,match[0])
        counts.append(dict(id=row["id"],threads=len(os.sched_getaffinity(0)),probes=probes,hits=hits,inserts=inserts,bytes=size))
        archive.writestr(row["id"]+".json",json.dumps(dict(source=row,seed=seed,analytics=result)))
(out/"worker_counts.tmp").unlink()
(out/"counts.json").write_text(json.dumps(counts,indent=2))
print("Table counts",sum(r["hits"] for r in counts),sum(r["probes"] for r in counts),counts[0]["bytes"],flush=True)
