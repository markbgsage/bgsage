#pragma once
#include "types.h"
#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <cstdio>
#include <memory>

namespace bgbot {
class TrialCubeTable {
    static constexpr unsigned capacity = 16384;
    struct Entry {
        Board board;
        uint64_t key, fp;
        unsigned count;
        bool top;
        float equity[8];
        std::array<float, NUM_OUTPUTS> probs;
    };
    std::array<std::atomic<unsigned char>, capacity> state_;
    std::unique_ptr<Entry[]> entries_{new Entry[capacity]};
    const bool count_ = std::getenv("BGSAGE_BENCH_TREE_COUNTS") != nullptr;
    mutable std::atomic<unsigned> probes_{0}, hits_{0}, inserts_{0};
public:
    TrialCubeTable() { for (auto& s : state_) s.store(0, std::memory_order_relaxed); }
    ~TrialCubeTable() {
        if (count_) std::fprintf(stderr, "trial_tree probes %u hits %u inserts %u bytes %zu\n",
            probes_.load(), hits_.load(), inserts_.load(), capacity * sizeof(Entry) + sizeof(*this));
    }
    bool get(uint64_t k, uint64_t fp, const Board& board, unsigned count, bool top,
             float* out, std::array<float, NUM_OUTPUTS>* probs) const {
        auto idx = k & (capacity - 1);
        if (count_) probes_.fetch_add(1, std::memory_order_relaxed);
        if (state_[idx].load(std::memory_order_acquire) != 2) return false;
        const auto& e = entries_[idx];
        if (e.key != k || e.fp != fp || e.count != count || e.top != top || e.board != board)
            return false;
        std::copy_n(e.equity, count, out);
        if (probs) *probs = e.probs;
        if (count_) hits_.fetch_add(1, std::memory_order_relaxed);
        return true;
    }
    void put(uint64_t k, uint64_t fp, const Board& board, unsigned count, bool top,
             const float* values, const std::array<float, NUM_OUTPUTS>& probs) {
        auto idx = k & (capacity - 1);
        unsigned char empty = 0;
        if (!state_[idx].compare_exchange_strong(empty, 1, std::memory_order_relaxed)) return;
        auto& e = entries_[idx];
        e.key = k; e.fp = fp; e.count = count; e.top = top;
        e.board = board;
        e.probs = probs;
        std::copy_n(values, count, e.equity);
        state_[idx].store(2, std::memory_order_release);
        if (count_) inserts_.fetch_add(1, std::memory_order_relaxed);
    }
};
inline thread_local TrialCubeTable* trial_tree_table = nullptr;
class TrialTreeScope {
    TrialCubeTable* previous_;
public:
    explicit TrialTreeScope(TrialCubeTable* next) : previous_(trial_tree_table) { trial_tree_table = next; }
    ~TrialTreeScope() { trial_tree_table = previous_; }
};
}
